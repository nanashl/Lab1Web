<template>
  <div class="about-us">
    <h1 class="about-title">О нашей компании</h1>
    <p class="about-description">
      Мы работаем на рынке автомобилей более 10 лет, предлагая нашим клиентам только лучшее.
      Наша команда профессионалов всегда готова помочь вам выбрать идеальный автомобиль, который
      соответствует вашим потребностям и бюджету.
    </p>
    
  </div>
</template>



<style scoped>
.about-us {
  padding: 40px;
  background-color: #f9f9f9;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.about-title {
  font-size: 2.5em;
  margin-bottom: 20px;
  color: #333;
}

.about-description {
  font-size: 1.2em;
  color: #666;
  margin-bottom: 40px;
}

.about-team {
  margin-top: 30px;
}

.team-title {
  font-size: 2em;
  margin-bottom: 20px;
  color: #444;
}

.team-member {
  display: inline-block;
  width: 200px;
  margin: 10px;
  text-align: center;
}

.team-image {
  width: 100%;
  height: auto;
  border-radius: 50%;
  margin-bottom: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.member-name {
  font-size: 1.1em;
  font-weight: bold;
  color: #333;
}

.member-role {
  font-size: 0.9em;
  color: #666;
}
</style>